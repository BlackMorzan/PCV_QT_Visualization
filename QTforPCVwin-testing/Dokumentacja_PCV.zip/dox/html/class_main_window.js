var class_main_window =
[
    [ "MainWindow", "class_main_window.html#ac7a113186b29a232ee55a68f6fa37f6c", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "Chart", "class_main_window.html#a5be1b81abdceada4811be42472bd5b15", null ],
    [ "chose_Vector", "class_main_window.html#a3d903a29aaf43f679a0fc6e5ea80a0ea", null ],
    [ "GetLastLog", "class_main_window.html#a53ea2941ff74c51b260958ac89c8bc8b", null ],
    [ "on_ChartChange_clicked", "class_main_window.html#aa711b8d4b2c53eed8385e7c3b48974c3", null ],
    [ "recive_vector", "class_main_window.html#a8773d2b40c1762d506f6c33fc66ee460", null ],
    [ "ChartMode", "class_main_window.html#a7832f6b1685092346ca3c1a555b2540c", null ],
    [ "connection", "class_main_window.html#a84fda33e480e6238e529fdda8576e077", null ],
    [ "Connection_Menager", "class_main_window.html#af9929c75b11531d77f8b52f7b3351773", null ],
    [ "Pos", "class_main_window.html#a3cfa261eb6c014e7262ac60e603e05d6", null ],
    [ "ui", "class_main_window.html#a35466a70ed47252a0191168126a352a5", null ]
];