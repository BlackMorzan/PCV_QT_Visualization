var class_custom_conn =
[
    [ "CustomConn", "class_custom_conn.html#ab5230d447f014deedeb40cc6edd704de", null ],
    [ "GetDouble", "class_custom_conn.html#a3bfcef5c0cced1664a70e2f45931706f", null ],
    [ "Init", "class_custom_conn.html#ae60734e886ad361449be3c9e54998890", null ],
    [ "Init", "class_custom_conn.html#ae60734e886ad361449be3c9e54998890", null ],
    [ "IsMessage", "class_custom_conn.html#a148f5076144c26004cd5639e8510ec9f", null ],
    [ "ReciveFullMessage", "class_custom_conn.html#a6fd79ef68ea1d968dc69d4677a22c612", null ],
    [ "ReciveFullMessage", "class_custom_conn.html#a6fd79ef68ea1d968dc69d4677a22c612", null ],
    [ "ReciveMessage", "class_custom_conn.html#abf0284f0b0f1c84ddf283bbead4355d6", null ],
    [ "ReciveMessageCount", "class_custom_conn.html#a835f7cadaa5e2bd2345ce9fc005715e5", null ],
    [ "ReciveMessageCount", "class_custom_conn.html#a835f7cadaa5e2bd2345ce9fc005715e5", null ],
    [ "ReciveString", "class_custom_conn.html#a3e8e8bff62d2cf8b4d0e86ca3dfab9af", null ],
    [ "ReciveString", "class_custom_conn.html#a3e8e8bff62d2cf8b4d0e86ca3dfab9af", null ],
    [ "Send", "class_custom_conn.html#a573cc4e960efa875981c6ae91216b27b", null ],
    [ "Send", "class_custom_conn.html#aff278f436a607e97208e0989be46d594", null ],
    [ "lenght", "class_custom_conn.html#ac262fc34cbe185718bfc223831732e8b", null ],
    [ "messageCnt", "class_custom_conn.html#a56ffc677b31dcd49b906199b2f6f8aba", null ],
    [ "RecivedDouble", "class_custom_conn.html#a2ce4a5667364510d33f70deff8d61325", null ],
    [ "sock", "class_custom_conn.html#ac4d1d7b76b8a4321b6a210255855416f", null ]
];