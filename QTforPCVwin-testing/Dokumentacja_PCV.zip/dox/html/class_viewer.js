var class_viewer =
[
    [ "Viewer", "class_viewer.html#a52be9f2c4058fe2c6d49810431252a3f", null ],
    [ "draw", "class_viewer.html#a9ce9d06343c4e089ac76b19f78fe29e4", null ],
    [ "init", "class_viewer.html#a255cc2d6f55fc8565e614618d41589b1", null ],
    [ "LastVector", "class_viewer.html#a204f49b09d7eb5ef1e678ced65ef5f92", null ]
];