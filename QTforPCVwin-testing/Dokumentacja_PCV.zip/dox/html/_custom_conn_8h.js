var _custom_conn_8h =
[
    [ "CustomConn", "class_custom_conn.html", "class_custom_conn" ],
    [ "HexCharStruct", "struct_hex_char_struct.html", "struct_hex_char_struct" ],
    [ "PORT", "_custom_conn_8h.html#a614217d263be1fb1a5f76e2ff7be19a2", null ],
    [ "hex", "_custom_conn_8h.html#a8c397caca29f6f6261bc32ab57974cf4", null ],
    [ "operator<<", "_custom_conn_8h.html#a2bcff2d6f4ed076961559a236cb7a92f", null ]
];