var class_globals =
[
    [ "Globals", "class_globals.html#a3b78cfdbe2809ad8b6b722969dda4425", null ],
    [ "GetRotation", "class_globals.html#ac7e92849572f416a9514d9aaba3486bf", null ],
    [ "SetRotation", "class_globals.html#a7e6725a6b01d60dd9989531fa9db0f1b", null ],
    [ "LastRotation", "class_globals.html#acaac0008ccba3f2a0f0b47a307c94738", null ]
];