var classthr___connection___menager =
[
    [ "thr_Connection_Menager", "classthr___connection___menager.html#a6631fff94664d816fef40944c3b3b8f9", null ],
    [ "decide_vector", "classthr___connection___menager.html#a717ef6bf909c4884f145411d4296ae61", null ],
    [ "emit_Vetors", "classthr___connection___menager.html#acd7194463ea9d4263968444973214497", null ],
    [ "NewLog", "classthr___connection___menager.html#a19fc492345962c58937d3517f0bd80c4", null ],
    [ "run", "classthr___connection___menager.html#aa107b54444c647edf554aae512968767", null ],
    [ "current_vetor", "classthr___connection___menager.html#a69ff96dfeb746ea808ed34cf3dc3bf80", null ],
    [ "PosMen", "classthr___connection___menager.html#adc68e8eac29a6637e92404617ecbbf8b", null ],
    [ "RotMen", "classthr___connection___menager.html#a25b583cb7ba8867fa538c62e27c6f028", null ],
    [ "Stop", "classthr___connection___menager.html#a246c6fa22b711a93ff148577b6031a65", null ],
    [ "ToPCV", "classthr___connection___menager.html#af96cdb4f7e9df349219243e4dac72ab2", null ],
    [ "VeloMen", "classthr___connection___menager.html#a646c58e4c8b86b16a48b56f4fbab173b", null ]
];