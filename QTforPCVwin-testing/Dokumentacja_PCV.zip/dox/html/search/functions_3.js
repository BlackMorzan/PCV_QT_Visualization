var searchData=
[
  ['getdouble',['GetDouble',['../class_custom_conn.html#a3bfcef5c0cced1664a70e2f45931706f',1,'CustomConn']]],
  ['getlastlog',['GetLastLog',['../class_main_window.html#a53ea2941ff74c51b260958ac89c8bc8b',1,'MainWindow']]],
  ['getrotation',['GetRotation',['../class_globals.html#ac7e92849572f416a9514d9aaba3486bf',1,'Globals']]],
  ['globals',['Globals',['../class_globals.html#a3b78cfdbe2809ad8b6b722969dda4425',1,'Globals']]]
];
