var searchData=
[
  ['globals',['Globals',['../class_globals.html',1,'']]]
];
