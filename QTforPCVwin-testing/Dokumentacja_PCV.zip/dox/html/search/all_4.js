var searchData=
[
  ['hexcharstruct',['HexCharStruct',['../struct_hex_char_struct.html',1,'']]]
];
