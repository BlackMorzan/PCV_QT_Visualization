var searchData=
[
  ['newlog',['NewLog',['../classthr___connection___menager.html#a19fc492345962c58937d3517f0bd80c4',1,'thr_Connection_Menager']]]
];
