var searchData=
[
  ['mainwindow',['MainWindow',['../class_main_window.html',1,'MainWindow'],['../class_main_window.html#ac7a113186b29a232ee55a68f6fa37f6c',1,'MainWindow::MainWindow()']]],
  ['messagecnt',['messageCnt',['../class_custom_conn.html#a56ffc677b31dcd49b906199b2f6f8aba',1,'CustomConn']]]
];
