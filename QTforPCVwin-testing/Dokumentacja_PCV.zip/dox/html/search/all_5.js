var searchData=
[
  ['init',['Init',['../class_custom_conn.html#ae60734e886ad361449be3c9e54998890',1,'CustomConn::Init()'],['../class_viewer.html#a255cc2d6f55fc8565e614618d41589b1',1,'Viewer::init()']]],
  ['ismessage',['IsMessage',['../class_custom_conn.html#a148f5076144c26004cd5639e8510ec9f',1,'CustomConn']]]
];
