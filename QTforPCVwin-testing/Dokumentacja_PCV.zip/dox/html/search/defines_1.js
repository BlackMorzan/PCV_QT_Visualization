var searchData=
[
  ['port',['PORT',['../_custom_conn_8h.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'PORT():&#160;CustomConn.h'],['../_my_client2_8h.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'PORT():&#160;MyClient2.h']]]
];
