var searchData=
[
  ['sock',['sock',['../class_custom_conn.html#ac4d1d7b76b8a4321b6a210255855416f',1,'CustomConn']]],
  ['stop',['Stop',['../classthr___connection___menager.html#a246c6fa22b711a93ff148577b6031a65',1,'thr_Connection_Menager']]]
];
