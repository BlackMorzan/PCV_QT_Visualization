var dir_06fb640ca6522b57e42289ba33a68e7d =
[
    [ "Circle.cpp", "_circle_8cpp_source.html", null ],
    [ "Circle.h", "_circle_8h_source.html", null ],
    [ "CustomConn.cpp", "_custom_conn_8cpp_source.html", null ],
    [ "CustomConn.h", "_custom_conn_8h.html", "_custom_conn_8h" ],
    [ "globals.cpp", "globals_8cpp_source.html", null ],
    [ "globals.h", "globals_8h_source.html", null ],
    [ "main.cpp", "main_8cpp_source.html", null ],
    [ "mainwindow.cpp", "mainwindow_8cpp_source.html", null ],
    [ "mainwindow.h", "mainwindow_8h_source.html", null ],
    [ "MyClient2.cpp", "_my_client2_8cpp_source.html", null ],
    [ "MyClient2.h", "_my_client2_8h_source.html", null ],
    [ "Threading.cpp", "_threading_8cpp_source.html", null ],
    [ "Threading.h", "_threading_8h_source.html", null ],
    [ "Viewer.cpp", "_viewer_8cpp_source.html", null ],
    [ "Viewer.h", "_viewer_8h_source.html", null ]
];