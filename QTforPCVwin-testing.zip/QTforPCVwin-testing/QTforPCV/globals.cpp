#include "globals.h"

Globals Glob;
