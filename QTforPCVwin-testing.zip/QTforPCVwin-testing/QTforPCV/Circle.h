#ifndef CIRCLE_H
#define CIRCLE_H

#include <QtGui>
#include <QWidget>

class Circle : public QWidget
{
    Q_OBJECT
public:
 //  MyWidget();

protected:
    void paintEvent(QPaintEvent *event);

signals:

public slots:

};

#endif // CIRCLE_H
