var searchData=
[
  ['on_5fchartchange_5fclicked',['on_ChartChange_clicked',['../class_main_window.html#aa711b8d4b2c53eed8385e7c3b48974c3',1,'MainWindow']]]
];
