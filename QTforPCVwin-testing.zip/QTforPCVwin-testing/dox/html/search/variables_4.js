var searchData=
[
  ['reciveddouble',['RecivedDouble',['../class_custom_conn.html#a2ce4a5667364510d33f70deff8d61325',1,'CustomConn']]],
  ['rotmen',['RotMen',['../classthr___connection___menager.html#a25b583cb7ba8867fa538c62e27c6f028',1,'thr_Connection_Menager']]]
];
