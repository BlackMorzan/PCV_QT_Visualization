var searchData=
[
  ['send',['Send',['../class_custom_conn.html#aff278f436a607e97208e0989be46d594',1,'CustomConn']]],
  ['setrotation',['SetRotation',['../class_globals.html#a7e6725a6b01d60dd9989531fa9db0f1b',1,'Globals']]]
];
