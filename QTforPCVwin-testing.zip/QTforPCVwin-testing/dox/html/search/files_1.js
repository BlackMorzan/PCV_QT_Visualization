var searchData=
[
  ['globals_2ecpp',['globals.cpp',['../globals_8cpp.html',1,'']]],
  ['globals_2eh',['globals.h',['../globals_8h.html',1,'']]]
];
