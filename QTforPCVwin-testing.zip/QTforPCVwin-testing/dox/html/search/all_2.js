var searchData=
[
  ['emit_5fvetors',['emit_Vetors',['../classthr___connection___menager.html#acd7194463ea9d4263968444973214497',1,'thr_Connection_Menager']]]
];
