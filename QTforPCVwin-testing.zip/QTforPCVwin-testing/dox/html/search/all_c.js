var searchData=
[
  ['send',['Send',['../class_custom_conn.html#aff278f436a607e97208e0989be46d594',1,'CustomConn']]],
  ['setrotation',['SetRotation',['../class_globals.html#a7e6725a6b01d60dd9989531fa9db0f1b',1,'Globals']]],
  ['sock',['sock',['../class_custom_conn.html#ac4d1d7b76b8a4321b6a210255855416f',1,'CustomConn']]],
  ['stop',['Stop',['../classthr___connection___menager.html#a246c6fa22b711a93ff148577b6031a65',1,'thr_Connection_Menager']]]
];
