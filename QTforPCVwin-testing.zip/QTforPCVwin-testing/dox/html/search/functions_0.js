var searchData=
[
  ['chose_5fvector',['chose_Vector',['../class_main_window.html#a3d903a29aaf43f679a0fc6e5ea80a0ea',1,'MainWindow']]],
  ['customconn',['CustomConn',['../class_custom_conn.html#ab5230d447f014deedeb40cc6edd704de',1,'CustomConn']]]
];
