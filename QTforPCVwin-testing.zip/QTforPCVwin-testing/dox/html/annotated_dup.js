var annotated_dup =
[
    [ "Circle", "class_circle.html", "class_circle" ],
    [ "CustomConn", "class_custom_conn.html", "class_custom_conn" ],
    [ "Globals", "class_globals.html", "class_globals" ],
    [ "HexCharStruct", "struct_hex_char_struct.html", "struct_hex_char_struct" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "thr_Connection_Menager", "classthr___connection___menager.html", "classthr___connection___menager" ],
    [ "Viewer", "class_viewer.html", "class_viewer" ]
];