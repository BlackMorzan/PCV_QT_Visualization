var hierarchy =
[
    [ "CustomConn", "class_custom_conn.html", null ],
    [ "Globals", "class_globals.html", null ],
    [ "HexCharStruct", "struct_hex_char_struct.html", null ],
    [ "QGLViewer", null, [
      [ "Viewer", "class_viewer.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QThread", null, [
      [ "thr_Connection_Menager", "classthr___connection___menager.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "Circle", "class_circle.html", null ]
    ] ]
];