var struct_hex_char_struct =
[
    [ "HexCharStruct", "struct_hex_char_struct.html#a34c6b5fff43a1a285aff900e3302e5e5", null ],
    [ "HexCharStruct", "struct_hex_char_struct.html#a34c6b5fff43a1a285aff900e3302e5e5", null ],
    [ "c", "struct_hex_char_struct.html#a6257e9b23c245ecdbfd9d3d20709009d", null ]
];